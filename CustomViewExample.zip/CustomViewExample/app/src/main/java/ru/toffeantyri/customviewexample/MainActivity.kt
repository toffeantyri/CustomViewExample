package ru.toffeantyri.customviewexample

import android.app.Activity
import android.os.Bundle
import androidx.core.app.ComponentActivity

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity)


    }
}

